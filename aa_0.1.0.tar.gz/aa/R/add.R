#' Add two names
#' @param x num1
#' @param y num2
#' @return return a number
#' @examples
#' add(1,0)
#' add(1,2)
#'

add <- function(x,y) {
  z = x + y
  print(z)
}
