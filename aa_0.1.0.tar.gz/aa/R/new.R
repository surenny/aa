

new <- function() {
  print("Hello, world!")
}
